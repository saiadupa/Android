package com.first.demo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    val click=findViewById<Button>(R.id.click_me)
    click.setOnClickListener{
        Toast.makeText(this,"hello",Toast.LENGTH_SHORT).show()

    val secondActButton=findViewById<Button>(R.id.button2)
    secondActButton.setOnClickListener {
        val I=Intent(this,MainActivity2::class.java)
        startActivity(I)
    }

    }
    }
}